﻿using System;
using System.Numerics;

namespace Programa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int nqq = 0, mj = 0;
            int[] numeros;
            int[] lista = { };
            bool repetidos = false;
            numeros = new int[nqq];
            double promedio;
            string s1 = null;
            
            //PEDIR NUMEROS
            //Ingresar los numeros

            Console.WriteLine("Ingresa la cantidad de numeros");
            nqq = int.Parse(Console.ReadLine());
            numeros = new int[nqq];

            for (int i = 0; i < nqq; i++)
            {
                Console.WriteLine("\ningrese el numero {0}", i + 1);
                numeros[i] = int.Parse(Console.ReadLine());
            }


            Console.Clear();




            //---------------------------------------------------------------


            //SWICH
            do 
            { 

            Console.WriteLine("1- INTERCAMBIAR LOS ELEMENTOS DE UN VECTOR");
            Console.WriteLine("2- AVERIGUAR SI LA LISTA DE NUMEROS ESTA ORDENADA DE MENOR A MAYOR");
            Console.WriteLine("3- AVERIGUAR SI LA LISTA ESTA DE MANERA CRECIENTE");
            Console.WriteLine("4- AVERIGUAR SI HAY NUMEROS REPETIDOS");
            Console.WriteLine("5- ORDENAR DE MENOR A MAYOR LA LISTA");
            Console.WriteLine("6- AVERIGUAR SI EL NUMERO T ESTA EN LA LISTA");
            Console.WriteLine("7- HALLAR EL PROMEDIO DE UN VECTOR");
            Console.WriteLine("8- SALIR");
            Console.WriteLine("NOTA:PROFE NO ME REPRUEBE JAJA):");
            Console.WriteLine("--------------------------------------------------------------------");

            string op = Console.ReadLine();
            
                switch (op)

                {
                    case "1":
                        {
                            Console.WriteLine("INTERCAMBIAR LOS ELEMENTOS DE UN VECTOR");
                            Console.WriteLine("---------------------------------------");

                            for (int i = 0; i < numeros.Length; i++)
                            {
                                for (int j = i + 1; j < numeros.Length; j++)
                                {
                                    int aux;
                                    if (numeros[i] < numeros[j])
                                    {
                                        aux = numeros[i];
                                        numeros[i] = numeros[j];
                                        numeros[j] = aux;
                                    }
                                }
                            }
                            Console.WriteLine("LOS DATOS ODRDENADOS SON:");
                            for (int i = 0; i < nqq; i++)
                            {
                                Console.WriteLine(numeros[i]);
                            }
                        }
                        break;

                    case "2":
                        {
                            Console.WriteLine("AVERIGUAR SI LA LISTA DE NUMEROS ESTA ORDENADA DE MENOR A MAYOR");
                            Console.WriteLine("---------------------------------------------------------------");

                            for (int i = 1; i < nqq; i++)
                            {
                                for (int p = 0; p < nqq - 1; p++)
                                {
                                    if (numeros[i] < numeros[p])
                                    {
                                        mj = numeros[i];
                                        numeros[i] = numeros[p];
                                        numeros[p] = mj;

                                    }
                                }
                            }

                            Console.WriteLine("LOS NUMEROS DE MENOR A MAYOR SON: ");

                            for (int q = 0; q < nqq; q++)
                            {
                                Console.Write(numeros[q] + " - ");

                            }
                        }
                        break;
                    case "3":
                        {
                            Console.WriteLine("AVERIGUAR SI LA LISTA ESTA DE MANERA CRECIENTE");
                            Console.WriteLine("----------------------------------------------");


                            for (int i = 1; i < nqq; i++)
                            {
                                for (int p = 0; p < nqq - 1; p++)
                                {
                                    if (numeros[i] < numeros[p])
                                    {
                                        mj = numeros[i];
                                        numeros[i] = numeros[p];
                                        numeros[p] = mj;

                                    }
                                }
                            }
                            Console.WriteLine();
                            Array.Reverse(numeros);

                            Console.WriteLine("LOS NUMEROS CRECIENTES SON");

                            for (int y = 0; y < nqq; y++)
                            {
                                Console.Write(numeros[y].ToString() + " - ");
                            }

                        }
                        break;
                    case "4":
                        {
                            Console.WriteLine("AVERIGUAR SI HAY NUMEROS REPETIDOS");
                            Console.WriteLine("----------------------------------");
                            for (var i = 0; i < lista.Length; i++)
                            {
                                int a = lista[i];
                                int c = i + 1;
                                for (int y = c; y < lista.Length; y++)
                                {
                                    int b = lista[y];
                                    if (a == b)
                                    {
                                        repetidos = true;
                                        Console.WriteLine("El Numero" + " " + a + " " + "Es el Repetido");
                                    }
                                }
                            }
                            if (repetidos == false)
                            {
                                Console.WriteLine("No Hay Numeros Repetidos");
                            }
                            break;
                        }
                    case "5":
                        {
                            Console.WriteLine("ORDENAR DE MENOR A MAYOR LA LISTA");
                            Console.WriteLine("---------------------------------");

                            for (int x = 1; x < nqq - 1; x++)
                            {
                                for (int y = 0; y < nqq - 1; y++)
                                {
                                    if (numeros[x] < numeros[y])
                                    {
                                        mj = numeros[x];
                                        numeros[x] = numeros[y];
                                        numeros[y] = mj;
                                    }
                                }
                            }
                            Console.WriteLine("-----------------------------");
                            Console.WriteLine("EL ORDENAMIENTO ES:");

                            for (int q = 0; q < nqq; q++)
                            {
                                Console.Write(numeros[q] + " - ");
                            }

                            Console.WriteLine();

                            Array.Reverse(numeros);
                            break;
                        }
                    case "6":
                        {
                            Console.WriteLine("AVERIGUAR SI EL NUMERO T ESTA EN LA LISTA");
                            Console.WriteLine("-----------------------------------------");

                            verificar(numeros);
                            static void verificar(int[] array)

                            {
                                Boolean valor = false;
                                int num;
                                Console.Write("\nIngrese el numero a evaluar: ");
                                num = int.Parse(Console.ReadLine());
                                for (int i = 0; i < array.Length; i++)
                                {
                                    if (array[i] == num)
                                    {
                                        valor = true;
                                    }
                                }
                                if (valor)
                                {
                                    Console.WriteLine("\t >CHI< ");
                                }
                                else
                                {
                                    Console.WriteLine("\t >NOSTA< ");
                                }


                            }
                            break;
                        }
                    case "7":
                        {
                            Console.WriteLine("PROMEDIO DE UN VECTOR");
                            Console.WriteLine("---------------------");


                            for (int i = 0; i < numeros.Length; i++)
                            {
                                nqq = nqq + numeros[i];
                            }
                            promedio = nqq / numeros.Length;
                            Console.WriteLine("---------------------------");
                            Console.WriteLine("LA SUMA DE TODOS LOS NUMEROS ES: " + nqq);
                            Console.WriteLine("EL PROMEDIO DE LOS NUMEROS ES: " + promedio);


                        }
                        break;
                    case "8":
                        {
                            Console.WriteLine("OPCION MODULO");
                            Console.WriteLine("-------------");
                        }

                        break;

                    default:
                        {
                            Console.WriteLine("ESA OPCIÓN NO EXISTE, GRACIAS");
                        }
                        break;

                        

                }
                Console.WriteLine("\nDESEA SEGUIR EJECUTANDO LA CONSOLA? (CHI/NEL)");
                s1 = Console.ReadLine();
            } while (s1 == "CHI" || s1 == "chi") ;

           
        }
    }
}

